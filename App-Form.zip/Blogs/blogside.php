<div class="col-lg-4 col-md-12 order-last">
                            <div class="widget-area">
                                <div class="search-widget mb-50">
                                    <div class="search-wrap">
                                        <input type="search" placeholder="Searching..." name="s" class="search-input" value="">
                                        <button type="submit" value="Search"><i class="flaticon-search"></i></button>
                                    </div>
                                </div>
                                <div class="recent-posts mb-50">
                                    <div class="widget-title">
                                        <h3 class="title">Recent Posts</h3>
                                    </div>
                                    
                                    <div class="recent-post-widget no-border">
                                        <div class="post-img">
                                            <a href="Blog-Detail-1.php"><img src="/assets/images/blog/inner/style2/1.jpg" alt="Benefits of Trademark registration" title="important Benefits of Trademark registration"></a>
                                        </div>
                                        <div class="post-desc">
                                            <a href="Blog-Detail-1.php"> Benefits of Trademark Registration</a>
                                        </div>
                                    </div>
                                    
                                    <div class="recent-post-widget">
                                        <div class="post-img">
                                            <a href="Blog-Detail-2.php"><img src="/assets/images/blog/inner/style2/2.jpg"  alt="how to apply for a trademark" title="How to Apply for a Trademark Business?"></a>
                                        </div>
                                        <div class="post-desc">
                                            <a href="Blog-Detail-2.php"> How to Apply for a Trademark Business?</a>
                                        </div>
                                    </div>
                                    <div class="recent-post-widget">
                                        <div class="post-img">
                                            <a href="Blog-Detail-3.php"><img src="/assets/images/blog/inner/style2/3.jpg" alt="How to file a copyright application" title="what Copyright is and how to file a copyright application"></a>
                                        </div>
                                        <div class="post-desc">
                                            <a href="Blog-Detail-3.php">What Copyright is and how to file a copyright application</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="categories">
                                    <div class="widget-title">
                                        <h3 class="title">Categories</h3>
                                    </div>
                                    <ul>
                                        <li><a href="javascript:void(0);">Trademark Registration</a></li>
                                        <li><a href="javascript:void(0);">Trademark Business</a></li>
                                        <li><a href="javascript:void(0);">Copyright</a></li>
                                        <li><a href="javascript:void(0);">Copyright Registration</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>