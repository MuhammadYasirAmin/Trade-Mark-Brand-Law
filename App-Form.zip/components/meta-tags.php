        <!-- meta tag -->
        <meta charset="utf-8">
        <title><?php echo $PageTitle; ?> | Trade Mark Brand Law</title>
        <!-- responsive tag -->
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- favicon -->
        <link rel="apple-touch-icon" href="/apple-touch-icon.png">
        <link rel="shortcut icon" type="image/x-icon" href="/assets/images/fav.png">